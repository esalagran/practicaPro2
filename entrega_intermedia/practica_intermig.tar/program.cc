/**
 * @mainpage Práctica PRO2
 */

/** @file program.cc
    @brief Programa principal para el ejercicio <em>Practica PRO2.Primavera 2020</em>.
*/


//#include "Cjt_Clusters.hh"
#include "Taula_de_distancies.hh"
#ifndef NO_DIAGRAM
#include <iostream>
#endif

using namespace std;

void crea_especie (int k, Cjt_Especies& Mostra,Taula_de_distancies& Taula, string ID, string gen) {
    bool creado = Mostra.existe_especie(ID);
    if (creado) {
        cout << "ERROR: La especie " << ID << " ya existe." << endl;
    }
    else {
        Mostra.crea_especie(ID, gen, k);
        Taula.afegeix_especie(ID, Mostra);
    }
}

int main () {
    cout.precision(6);
    int k;
    cin >> k;
    Cjt_Especies Mostra;
    //Cjt_Clusters Arbre;
    Taula_de_distancies Taula;
    string ordre;
    cin >> ordre;
    while (ordre != "fin") {
        if (ordre == "crea_especie") {
            string ID, gen;
            cin >> ID >> gen;
            cout << "# " << ordre <<" " << ID << " " << gen << endl;
            crea_especie(k, Mostra, Taula, ID, gen);
        }
        else if (ordre == "obtener_gen") {
            string ID;
            cin >> ID;
            cout << "# " << ordre << " " << ID << endl;
            bool existe = Mostra.existe_especie(ID);
            if (existe) {
                string gen;
                gen = Mostra.obtener_gen(ID);
                cout << gen << endl;
            }
            else cout << "ERROR: La especie " << ID << " no existe." << endl;
        }
        else if (ordre == "distancia") {
            string ID1, ID2;
            cin >> ID1 >> ID2;
            cout << "# " << ordre << " " << ID1 << " " << ID2 << endl;
            bool e1_existe = Mostra.existe_especie(ID1);
            bool e2_existe = Mostra.existe_especie(ID2);
            if (e1_existe and e2_existe) {
                double dist;
                dist = Taula.distancia(ID1,ID2); 
                cout << dist << endl;
            }
            else if (not e1_existe and e2_existe) {
                cout << "ERROR: La especie " << ID1 << " no existe." << endl;
            }
            else if (e1_existe and not e2_existe) cout << "ERROR: La especie " << ID2 << " no existe." << endl;
            else cout << "ERROR: La especie " << ID1 << " y la especie " << ID2 << " no existen." << endl;
        }
        
        else if (ordre == "elimina_especie") {
            string ID;
            cin >> ID;
            cout << "# " << ordre << " " << ID << endl;
            bool eliminado = Mostra.existe_especie(ID);
            if (eliminado) {
                Taula.eliminar_especie(ID);
                Mostra.elimina_especie(ID);
            }
            else cout << "ERROR: La especie " << ID << " no existe." << endl;
        }
        else if (ordre == "existe_especie") {
            string ID;
            cin >> ID;
            cout << "# " << ordre << ' ' << ID << endl;
            bool exist = Mostra.existe_especie(ID);
            if (exist) {
                cout << "SI" << endl;
            }
            else cout << "NO" << endl;
        }
        else if (ordre == "lee_cjt_especies") {
            int n;
            cin >> n;
            cout << "# " << ordre << endl;
            Mostra.eliminar_totes();
            Taula.buidar_taula();
            for (int i = 0; i < n; ++i) {
                string ID, gen;
                cin >> ID >> gen;
                crea_especie(k, Mostra, Taula, ID, gen);
            }
        }
        else if (ordre == "imprime_cjt_especies") {
            cout << "# " << ordre << endl;
            Mostra.imprime_cjt_especies();
        }
        else if (ordre == "tabla_distancias") {
            cout << "# " << ordre << endl;
            Taula_de_distancies taula_aux = Taula;
            taula_aux.tabla_distancias();
        }
        else if (ordre == "inicializa_clusters") {
            //Arbre.inicializa_clusters();
        }
        else if (ordre == "ejecutar_paso_wpgma") {
            //Arbre.ejecutar_paso_wpgma(Arbre);
        }
        else if (ordre == "imprime_cluster") {
            //Arbre.imprime_cluster(Arbre);
        }
        else if (ordre == "imprime_arbol_filogenetico") {
            //Arbre.imprime_arbol_filogenetico(Arbre);
        }
        cin >> ordre;
        cout << endl;
    }
}
