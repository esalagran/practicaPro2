/** @file Taula_de_distancies.hh
    @brief Especificación de la clase Taula_de_distancies
*/

#ifndef TAULA_DE_DISTANCIES_HH
#define TAULA_DE_DISTANCIES_HH

#include "Cjt_Especies.hh"

#ifndef NO_DIAGRAM 
#include <map>
#include <string>
#endif
using namespace std;

/** @class Taula_de_distancies
    @brief Representa una Taula_de_distancies 


    Contiene un map con clave string i valor map. el segundo map tiene clave string i valor double que sirve para anotar la distancia entre especies
*/

class Taula_de_distancies {
    
    private:
        
    map <string, map <string, double>> Taula;
        
    public:
        
        //Constructores:
        
        /** @brief Creadora por defecto. 
            \pre <em>cierto</em>
            \post El resultado es una tabla de distancias vacía
            \coste Constante
        */  
        
        Taula_de_distancies();
        /* Pre: cert */
        /* Post: el resultado es un conjunto de especies vacío */
        
        //Destructores:
        
        //~Taula_de_distancies();
        
        //Modificadoras:
        
        /** @brief Modificadora de añadir una especie.
            \pre <em>cierto</em>
            \post El parámetro implícito pasa a contener una especie mas y mas distancias 
            \coste Constante
        */
        
        void afegeix_especie(string id, Cjt_Especies& Mostra);
        
        /** @brief Modificadora de eliminar una especie.
            \pre <em>cierto</em>
            \post El parámetro implícito pasa a contener una especie menos y menos distancias
            \coste Constante
        */
        
        void eliminar_especie(string ID);
        
        //Consultores:
        
        /** @brief Consultora de distancia entre dos especies 
            \pre <em>cierto</em>
            \post El resultado es la distancia entre la primera especie y la segunda
            \coste Constante
        */
        
        double distancia(string ID1, string ID2);
        
        //Escribir:
        
        /** @brief Operación de escritura

            \pre <em>cierto</em>
            \post Escribe el contenido del parámetro implícito por el canal estándar de salida
            \coste Lineal respecto al número de especies del parámetro implícito
        */
        
        void tabla_distancias();
        
        double obtener_distancia(vector<string>& e1, vector<string>& e2);
        
        void buidar_taula();
        
        
};
#endif
        
